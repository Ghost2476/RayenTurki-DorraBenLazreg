<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$response = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $conn = new mysqli("localhost", "root", "", "MmeRim");
    if ($conn->connect_error) {
        $response = "Connection failed: " . $conn->connect_error;
    } else {
        $name = $_POST['name'] ?? '';
        $surname = $_POST['surname'] ?? '';
        $birthdate = $_POST['birthdate'] ?? '';
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        $number = $_POST['number'] ?? '';
        $ville = $_POST['ville'] ?? '';
        $gouvernerat = $_POST['gouvernerat'] ?? '';

        if (!$name || !$surname || !$birthdate || !$email || !$password || !$number || !$ville || !$gouvernerat) {
            $response = "Error: Missing fields!";
        } else {
            $stmt = $conn->prepare("INSERT INTO users (name, surname, birthdate, email, password, number, ville, gouvernerat) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssss", $name, $surname, $birthdate, $email, $password, $number, $ville, $gouvernerat);

            if ($stmt->execute()) {
                echo "Success";
                exit;
            } else {
                $response = "Database Error: " . $stmt->error;
            }
            $stmt->close();
        }
        $conn->close();
    }

    echo $response;
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign-In</title>
    <link rel="stylesheet" href="style/styleIndex.css">
    <link rel="icon" href="src/Img/logo.png" type="image/png">
    <link rel="stylesheet" href="style/styleIndex.css">
    <script src="script/Script.js"></script>
</head>
<body>
    <nav class="navbar">
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="#">About</a></li>
            <li><a href="service.html">Services</a></li>
            <li><a href="#aside">Contact</a></li>
        </ul>
        <img src="src/Img/logo.png" class="logo_TR">
    </nav>

    <aside class="sidebar" id="aside">
        <ul>
            <li>Profile</li>
            <li><a href="#"><img src="src/Img/facebook.png" class="logo"></a></li>
            <li><a href="#"><img src="src/Img/instagram.png" class="logo"></a></li>
            <li><a href="#"><img src="src/Img/tiktok.png" class="logo"></a></li>
            <li><a href="#"><img src="src/Img/gmail.png" class="logo"></a></li>
        </ul>
        <img src="src/Img/logo.png" class="logo_BL">
    </aside>

    <div>
        <form class="formS" method="POST" action="" >
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" class="inputS" required>

            <label for="surname">Surname:</label>
            <input type="text" id="surname" name="surname" class="inputS" required>

            <label for="birthdate">Birthdate:</label>
            <input type="date" id="birthdate" name="birthdate" class="inputS" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" class="inputS" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" class="inputS" required>

            <label for="confirm-password">Confirm Password:</label>
            <input type="password" id="confirm-password" name="confirm-password" class="inputS" required>

            <label for="number">Mobile:</label>
            <input type="number" id="number" name="number" placeholder="+216" class="inputS" required>

            <label for="ville">Ville:</label>
            <input type="text" id="ville" name="ville" class="inputS" required>

            <label for="gouvernerat">Gouvernerat:</label>
            <input type="text" id="gouvernerat" name="gouvernerat" class="inputS" required>

            <button type="submit" class="B-SI" onclick="SignIn()">Sign-In</button>
        </form>
    </div>

    <footer class="footer">
        <p>&copy; 2024 Sayarti. All rights reserved.</p>
    </footer>
</body>
</html>
