<?php
$host = 'localhost';
$db   = 'MmeRim';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

try {
    $conn = new PDO($dsn, $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

$search = $_POST['search'] ?? '';

$sql = "SELECT * FROM components WHERE name LIKE :search";
$stmt = $conn->prepare($sql);
$stmt->execute(['search' => '%' . $search . '%']);
$filtered_components = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!empty($_POST['order'])) {
    $orderedItem = htmlspecialchars($_POST['order']);
    
    $sql = "UPDATE components SET stock = FALSE WHERE name = :orderedItem";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['orderedItem' => $orderedItem]);

    header("Location: " . $_SERVER['PHP_SELF'] . "?ordered=" . urlencode($orderedItem));
    exit;
}

$promotions = [
    "🔥 20% off on all Spark Plugs this week!",
    "💥 Free shipping for orders over $50!",
    "🚗 Buy 1 Oil Filter, get 1 at 50% off!",
    "⚙️ Turbo Kits - Limited Stock Discount!",
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/styleIndex.css">
    <title>Upgrade</title>
    <link rel="icon" href="src/Img/logo.png" type="image/png">
</head>
<body>
    <nav class="navbar">
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="#">About</a></li>
            <li><a href="service.html">Services</a></li>
            <li><a href="#aside">Contact</a></li>
        </ul>
        <img src="src/Img/logo.png" class="logo_TR">
    </nav>

    <aside class="sidebar" id="aside">
        <ul>
            <li>Profile</li>
            <li><a href="https://www.facebook.com/profile.php?id=61560993684603"><img src="src/Img/facebook.png" class="logo"></a></li>
            <li><a href="https://www.instagram.com/tn.gears/"><img src="src/Img/instagram.png" class="logo"></a></li>
            <li><a href="https://www.tiktok.com/@tunisian.gears?lang=fr"><img src="src/Img/tiktok.png" class="logo"></a></li>
            <li><a href="https://mail.google.com/mail/?view=cm&fs=1&to=tunisian.gears@gmail.com"><img src="src/Img/gmail.png" class="logo"></a></li>
        </ul>
        <img src="src/Img/logo.png" class="logo_BL">
    </aside>

    <h1 class="section00">Upgrade Service 🧑‍🔧</h1>

    <div>
        <section class="section10">
            <h3 class="h3">Look for components that match your car</h3>
            <form method="POST">
                <input type="text" name="search" placeholder="(Air Filter, Oil Filter, Spark Plugs...)" value="<?= htmlspecialchars($search) ?>" class="inputU">
            </form>
            <div class="promotions">
                <div class="promo-title">🔥 Current Promotions & Big Sales:</div>
                <ul>
                    <?php foreach ($promotions as $promo): ?>
                        <li class="promo-item"><?= htmlspecialchars($promo) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div id="component-list" style="<?= $search ? 'display: block;' : 'display: none;' ?>">
                <ul>
                    <?php foreach ($filtered_components as $component): ?>
                        <li>
                            <?= htmlspecialchars($component['name']) ?> -
                            <?= $component['stock'] ? "(In Stock)" : '<span class="out-of-stock">(Out of Stock)</span>' ?>
                            <?php if ($component['stock']): ?>
                                <form method="post" style="display:inline;">
                                    <input type="hidden" name="order" value="<?= htmlspecialchars($component['name']) ?>">
                                    <button type="submit" class="command-btn">Command</button>
                                </form>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div id="order-message" style="display: <?= isset($_GET['ordered']) ? 'block' : 'none'; ?>;">
                <?php
                    if (isset($_GET['ordered'])) {
                        $orderedItem = htmlspecialchars($_GET['ordered']);
                        echo "<p class='success-message'>✅ You have ordered: <strong>$orderedItem</strong></p>";
                    }
                ?>
            </div>
        </section>
    </div>

    <footer class="footer">
        <p>&copy; 2024 Sayarti. All rights reserved.</p>
    </footer>
</body>
</html>
