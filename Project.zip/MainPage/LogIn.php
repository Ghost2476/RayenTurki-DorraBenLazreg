<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$host = 'localhost';
$dbname = 'MmeRim';
$username = 'root';
$password = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST["email"] ?? '';
    $password = $_POST["password"] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user["password"])) {
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["user_email"] = $user["email"];
    

        $stmt = $pdo->prepare("INSERT INTO logins (user_id) VALUES (?)");
        $stmt->execute([$user["id"]]);
        header("Location: service.html");
        exit();
    } else {
        $error = "Invalid email or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/styleIndex.css">
    <title>Log-In</title>
    <link rel="icon" href="src/Img/logo.png" type="image/png">
</head>

<body>
    <nav class="navbar">
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="#">About</a></li>
            <li><a href="service.html">Services</a></li>
            <li><a href="#aside">Contact</a></li>
        </ul>
        <img src="src/Img/logo.png" class="logo_TR">
    </nav>

    <aside class="sidebar" id="aside">
        <ul>
            <li>Profile</li>
            <li><a href="https://www.facebook.com/profile.php?id=61560993684603"><img src="src/Img/facebook.png" class="logo"></a></li>
            <li><a href="https://www.instagram.com/tn.gears/"><img src="src/Img/instagram.png" class="logo"></a></li>
            <li><a href="https://www.tiktok.com/@tunisian.gears?lang=fr"><img src="src/Img/tiktok.png" class="logo"></a></li>
            <li><a href="https://mail.google.com/mail/?view=cm&fs=1&to=tunisian.gears@gmail.com"><img src="src/Img/gmail.png" class="logo"></a></li>
        </ul>
        <img src="src/Img/logo.png" class="logo_BL">
    </aside>

    <div>
        <form class="formB" method="POST" action="">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" class="inputL" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" class="inputL" required>
            <?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
            <div class="LIB">
                <button type="button" onclick="resetP()" class="B-R">Reset Password</button>
                <button type="submit" class="B-LI">Log In</button> 
            </div>
        </form>
    </div>

    <footer class="footer">
        <p>&copy; 2024 Sayarti. All rights reserved.</p>
    </footer>
</body>

</html>
