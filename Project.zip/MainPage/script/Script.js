function SignIn() {
            const name = document.getElementById('name').value.trim();
            const surname = document.getElementById('surname').value.trim();
            const birthdate = document.getElementById('birthdate').value.trim();
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value.trim();
            const confirmPassword = document.getElementById('confirm-password').value.trim();
            const number = document.getElementById('number').value.trim();
            const ville = document.getElementById('ville').value.trim();
            const gouvernerat = document.getElementById('gouvernerat').value.trim();

            if (!name || !surname || !birthdate || !email || !password || !confirmPassword || !number || !ville || !gouvernerat) {
                alert("All fields must be filled.");
                return;
            }

            if (!email.includes('@')) {
                alert("Invalid email format.");
                return;
            }

            const birthYear = new Date(birthdate).getFullYear();
            const currentYear = new Date().getFullYear();
            if (birthYear < 1900 || birthYear > currentYear) {
                alert("Invalid birth year.");
                return;
            }

            if (password !== confirmPassword) {
                alert("Passwords do not match.");
                return;
            }

            if (!/^\d{8}$/.test(number)) {
                alert("Mobile number must be exactly 8 digits.");
                return;
            }

            const formData = new FormData();
            formData.append("name", name);
            formData.append("surname", surname);
            formData.append("birthdate", birthdate);
            formData.append("email", email);
            formData.append("password", password);
            formData.append("number", number);
            formData.append("ville", ville);
            formData.append("gouvernerat", gouvernerat);

            fetch("SignIn.php", {
                method: "POST",
                body: formData
            })
            .then(response => response.text())
            .then(result => {
                console.log("PHP says:", result);
                if (result.trim() === "Success") {
                    
                    window.location.href = "service.php";
                } else {
                    alert(result);
                }
            })
            .catch(error => {
                console.error("Error:", error);
                alert("Something went wrong.");
            });
            
        }


/*function LogIn() {
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();

    if (!email || !password) {
        alert("Please enter both email and password.");
        return;
    }

    const formData = new FormData();
    formData.append("email", email);
    formData.append("password", password);

    fetch("login.php", {
        method: "POST",
        body: formData
    })
    .then(response => response.text())
    .then(result => {
        alert(result);
        if (result.toLowerCase().includes("success")) {
            window.location.href = "service.html";
        }
    })
    .catch(error => {
        console.error("Error:", error);
        alert("Login failed.");
    });
}*/

