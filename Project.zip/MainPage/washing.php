<?php
$host = 'localhost';
$db   = 'MmeRim';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

try {
    $conn = new PDO($dsn, $user, $pass);

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}


$nameErr = $dateErr = $numberErr = $cityErr = $addressErr = $reservationMessage = "";

$takenDates = [];

try {
    $sql = "SELECT date FROM taken_dates";
    $stmt = $conn->query($sql);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $takenDates[] = $row['date'];
    }
} catch (PDOException $e) {

    die("Error fetching taken dates: " . $e->getMessage());
}





$cities = [
    "Tunis", "Sfax", "Sousse", "Kairouan", "Bizerte", "Gabes", "Ariana", "Nabeul", "Mahdia", "Monastir", 
    "Gafsa", "Kasserine", "Zaghouan", "Beja", "Medenine", "Tozeur", "Jendouba", "Siliana", "Kébili", "La Manouba", 
    "Manouba", "Ben Arous", "El Kef", "Tataouine", "Kairouan"
];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $date = $number = $city = $address = "";


    if (empty($_POST["name"])) {
        
        $nameErr = '<p style="color: #a60000; font-weight: bold; margin-top:10px;">❌ Name is required</p>';
    } else {
        $name = test_input($_POST["name"]);
        if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
            $nameErr = '<p style="color: #a60000;margin-top:10px;">❌ Only Letters ans spaces ere required</p>';
        }
    }


    if (empty($_POST["date"])) {
        $dateErr = '<p style="color: #a60000;margin-top:10px;">❌ Date is required</p>';
    } else {
        $date = test_input($_POST["date"]);
        if (in_array($date, $takenDates)) {
            $dateErr ='<p style="color: #a60000;margin-top:10px;">❌ Date is already taken</p>';
        }
    }

    if (empty($_POST["number"])) {
        $numberErr = '<p style="color: #a60000;margin-top:10px;">❌ Mobile number is required</p>';
    } else {
        $number = test_input($_POST["number"]);
        if (!preg_match("/^\d{8}$/", $number)) {
            $numberErr =  '<p style="color: #a60000; margin-top:10px;">❌ Mobile number must be exactly 8 digits</p>';
        }
    }

    if (empty($_POST["city"])) {
        $cityErr =  '<p style="color: #a60000;margin-top:10px;">❌ City required</p>';
    } else {
        $city = test_input($_POST["city"]);
    }


    if (empty($_POST["address"])) {
        $addressErr = '<p style="color: #a60000;margin-top:10px;">❌ Address required</p>';
    } else {
        $address = test_input($_POST["address"]);
    }


    if (empty($nameErr) && empty($dateErr) && empty($numberErr) && empty($cityErr) && empty($addressErr)) {

        $stmt = $conn->prepare("INSERT INTO taken_dates (date) VALUES (:date)");
        $stmt->execute(['date' => $date]);



        $stmt2 = $conn->prepare("INSERT INTO reservations (name, date, number, city, address) VALUES (:name, :date, :number, :city, :address)");
        $stmt2->execute([
        'name' => $name,
        'date' => $date,
        'number' => $number,
        'city' => $city,
        'address' => $address
]);


        $reservationMessage = "✅ Reservation Successful!<br>Date: $date<br>Name: $name<br>Mobile: $number<br>City: $city<br>Address: $address";

    }
}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/styleIndex.css">
    <title>Washing Service Reservation</title>
    <link rel="icon" href="src/Img/logo.png" type="image/png">
</head>
<body>
    <nav class="navbar">
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="#">About</a></li>
            <li><a href="service.html">Services</a></li>
            <li><a href="#aside">Contact</a></li>
        </ul>
        <img src="src/Img/logo.png" class="logo_TR">
    </nav>

    <aside class="sidebar" id="aside">
        <ul>
            <li>Profile</li>
            <li><a href="https://www.facebook.com/profile.php?id=61560993684603"><img src="src/Img/facebook.png" class="logo"></a></li>
            <li><a href="https://www.instagram.com/tn.gears/"><img src="src/Img/instagram.png" class="logo"></a></li>
            <li><a href="https://www.tiktok.com/@tunisian.gears?lang=fr"><img src="src/Img/tiktok.png" class="logo"></a></li>
            <li><a href="https://mail.google.com/mail/?view=cm&fs=1&to=tunisian.gears@gmail.com"><img src="src/Img/gmail.png" class="logo"></a></li>
        </ul>
        <img src="src/Img/logo.png" class="logo_BL">
    </aside>

    <h1 class="section00">Washing Service 🧽</h1>

    <div>
        <section class="section11">
            <h3 class="h4" style="margin-left:27%;">Reserve Now</h3>
            <form method="POST" class="formA">
                <label for="name" style="font-size:25px; margin-bottom:10px;">Name :</label>
                <input type="text" id="name" name="name" class="input2" value="<?= isset($name) ? $name : ''; ?>">
                <span class="error"><?= $nameErr; ?></span>

                <label for="date" style="font-size:25px;margin-bottom:10px;">Date you wanna Reserve:</label>
                <select id="date" name="date" class="input2">
                    <?php
                    $start = strtotime("2025-05-01");
                    $end = strtotime("2025-12-31");

                    while ($start <= $end) {
                        $formatted = date("Y-m-d", $start);
                        $isTaken = in_array($formatted, $takenDates);

                        echo "<option value='$formatted' style='color:" . ($isTaken ? "#a60000" : "black") . "' " . 
                            ($isTaken ? "disabled" : "") .
                            ($date == $formatted ? " selected" : "") . ">" . 
                            date("l, d M Y", $start) . ($isTaken ? " (Taken)" : "") . "</option>";

                        $start = strtotime("+1 day", $start);
                    }
                    ?>
                </select>
                <?= $dateErr ?>
                <span class="error"><?= $dateErr; ?></span>

                <label for="number" style="font-size:25px; margin-bottom:10px;">Mobile:</label>
                <input type="number" id="number" name="number" placeholder="+216" pattern="\d{8}" class="input2" value="<?= isset($number) ? $number : ''; ?>">
                <span class="error"><?= $numberErr; ?></span>

                <label for="city" style="font-size:25px; margin-bottom:10px;">City:</label>
                <select id="city" name="city" class="input2">
                    <option value="">Select a City</option>
                    <?php foreach ($cities as $c): ?>
                        <option value="<?= $c; ?>" <?= isset($city) && $city == $c ? 'selected' : ''; ?>><?= $c; ?></option>
                    <?php endforeach; ?>
                </select>
                <span class="error"><?= $cityErr; ?></span>

                <label for="address" style="font-size:25px; margin-bottom:10px;">Address:</label>
                <input type="text" id="address" name="address" class="input2" value="<?= isset($address) ? $address : ''; ?>">
                <span class="error"><?= $addressErr; ?></span>

                <button type="submit" class="submit-btn">Reserve</button>
                <p style="margin-top: 15px; font-weight: bold; color: <?php echo strpos($reservationMessage, '✅') === 0 ? 'green' : 'red'; ?>;">
                <?php echo $reservationMessage; ?>
                </p>
            </form>
        </section>
        
        <?php if ($reservationMessage): ?>
            <section class="reservation-confirmation">
                <p><?= $reservationMessage; ?></p>
            </section>
        <?php endif; ?>
    </div>

    <footer class="footer">
        <p>&copy; 2024 Sayarti. All rights reserved.</p>
    </footer>
</body>
</html>
